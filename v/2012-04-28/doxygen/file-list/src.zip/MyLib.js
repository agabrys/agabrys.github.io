/**
 * @file MyLib.js
 * Define library "package" object. Contains documentation main page description.
 */

/**
 * @mainpage
 * Description.
 */

/**
 * My library "package" object.
 */
MyLib = {};
