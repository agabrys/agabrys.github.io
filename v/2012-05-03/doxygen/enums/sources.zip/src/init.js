/**
 * @file src/init.js
 * Root file for GA library.
 */

/**
 * @namespace GA
 * Root namespace.
 */
GA = {};
