/**
 * @file src/Class.js
 * Contains GA::Class class.
 */

/**
 * @class GA::Class
 * Parent class for all classes. Implements methods to create new classes.
 */
GA.Class = {};
GA.Class_Base = {};
/**
 * @fn Class Class()
 * @public @memberof GA::Class
 * Constructor.
 */
GA.Class_Base.initialize = function() {
    // do nothing
};
/**
 * @fn boolean equals(Object other)
 * @public @memberof GA::Class
 * Indicates whether some other object is "equal to" this one.
 * The equals method implements an equivalence relation on non-null object references:
 * <ul>
 * <li>It is reflexive: for any non-null reference value x, x.equals(x) should return true.</li>
 * <li>It is symmetric: for any non-null reference values x and y, x.equals(y) should return true if and only if
 * y.equals(x) returns true.</li>
 * <li>It is transitive: for any non-null reference values x, y, and z, if x.equals(y) returns true and y.equals(z)
 * returns true, then x.equals(z) should return true.</li>
 * <li>It is consistent: for any non-null reference values x and y, multiple invocations of x.equals(y) consistently
 * return true or consistently return false, provided no information used in equals comparisons on the objects is
 * modified.</li>
 * <li>For any non-null reference value x, x.equals(null) should return false.</li>
 * </ul>
 * The equals method for class Object implements the most discriminating possible equivalence relation on objects; that
 * is, for any non-null reference values x and y, this method returns true if and only if x and y refer to the same
 * object (x === y has the value true). Note that it is generally necessary to override the hashCode method whenever this
 * method is overridden, so as to maintain the general contract for the hashCode method, which states that equal objects
 * must have equal hash codes.
 * @param other - other object with which to compare.
 * @return true if this object is the same as the obj argument; false otherwise.
 */
// JS.Class creates this method
/**
 * @fn boolean isA(Class klass)
 * @public @memberof GA::Class
 * Tests if this object is an instance of klass.
 * @return true if this object is an instance of klass, otherwise false.
 */
GA.Class_Base.isA = function(klass) {
    if(klass === GA.Class) {
        return true;
    }
    return JS.Kernel.isA.apply(this, [klass]);
};
/**
 * @fn String toString()
 * @public @memberof GA::Class
 * Returns text representation of this object.
 * @return text representation of this object.
 */
// JS.Class creates this method

GA.Class_Base = new JS.Class('GA.Class', GA.Class_Base);

/**
 * @fn static Class makeClass(String name, Class parent, Object methods)
 * @public @memberof GA::Class
 * Creates a new class which is a subclass of parent.
 * @param name class full name (with namespaces).
 * @param parent parent class.
 * @param methods object which contains class methods.
 * @return a new class which is a subclass of parent.
 * @throws Exception if methods object contains invalid constructor definition.
 */
/**
 * @fn static Class makeClass(String name, Object methods)
 * @public @memberof GA::Class
 * Creates a new class which is a subclass of Class.
 * @param name class full name (with namespaces).
 * @param methods object which contains class methods.
 * @return a new class which is a subclass of Class.
 * @throws Exception if methods object contains invalid constructor definition.
 */
GA.Class.makeClass = function() {
    var name = arguments[0].replace(/::/g, '.');
    var parent, methods;
    if(arguments.length === 3 && arguments[1] !== GA.Class) {
        parent = arguments[1];
        methods = arguments[2];
    } else {
        parent = GA.Class_Base;
        methods = arguments[1];
    }
    GA.Class._initializeConstructor(name, methods);
    return new JS.Class(name, parent, methods);
};

GA.Class._initializeConstructor = function(name, methods) {
    if( typeof methods.initialize === 'function') {
        var functionBody = GA.Class._getFunctionBodyInString(methods.initialize);
        if(!GA.Class._isCallParentConstructor(functionBody) && !GA.Class._isThrowExceptionInFirstInstruction(functionBody)) {
            throw new GA.Exception('Class "' + name + '" must call parent constructor as first instruction or throw exception!');
        }
    } else if( typeof methods.initialize === 'undefined') {
        methods.initialize = function() {
            this.callSuper();
        };
    } else {
        throw new GA.Exception('Class "' + name + '" has invalid constructor definition (must be equal to undefined or function)!');
    }
};

GA.Class._isCallParentConstructor = function(functionBody) {
    var index = functionBody.indexOf('this.callSuper(');
    if(index === 0) {
        return true;
    } else {
        return false;
    }
};

GA.Class._isThrowExceptionInFirstInstruction = function(functionBody) {
    var index = functionBody.indexOf('throw');
    if(index === 0) {
        return true;
    } else {
        return false;
    }
};

GA.Class._getFunctionBodyInString = function(func) {
    var functionBody = func.toString();
    var index = functionBody.indexOf('{');
    functionBody = functionBody.substr(index + 1);
    index = functionBody.lastIndexOf('}');
    functionBody = functionBody.substring(0, index);
    return functionBody.replace(/^(\s)*/, '').replace(/(\s)*$/, '');
};
