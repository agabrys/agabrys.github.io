/**
 * @file src/Enum.js
 * Contains GA::Enum enum.
 */

/**
 * @class GA::Enum
 * @extends GA::Class
 * Parent class for all enums. Implements methods to create new enums.
 */
// XXX delete when doxygen correct https://bugzilla.gnome.org/show_bug.cgi?id=674983
/**
 * @fn static Class makeClass(String name, Class parent, Object methods)
 * @private @memberof GA::Enum
 */
/**
 * @fn static Class makeClass(String name, Object methods)
 * @private @memberof GA::Enum
 */
GA.Enum = {};
GA.Enum_Base = {};
/**
 * @fn Enum Enum(String name)
 * @protected @memberof GA::Enum
 * Constructor.
 */
GA.Enum_Base.initialize = function(name) {
    this.callSuper();
    this._name = name;
};
/**
 * @fn String getName()
 * @public @memberof GA::Enum
 * Returns name of this enum constant.
 * @return name of this enum constant.
 */
GA.Enum_Base.getName = function() {
    return this._name;
};
GA.Enum_Base.isA = function(klass) {
    if(klass === GA.Enum) {
        return true;
    }
    return this.callSuper(klass);
};
/**
 * @fn String toString()
 * @public @memberof GA::Enum
 * Returns text representation of this enum constant. Examples:
 * <ul>
 * <li>for enum constant SAMPLE_VALUE returns SampleValue</li>
 * <li>for enum constant SA_M_PLE returns SaMPle</li>
 * <li>for enum constant SAM__P_LE__VALUE returns SamPLeValue</li>
 * </ul>
 * @return text representation of this enum constant.
 */
GA.Enum_Base.toString = function() {
    var parts = this._name.split('_');
    var string = '';
    for(var i = 0; i < parts.length; ++i) {
        if(parts[i].length !== 0) {
            if(parts[i].length > 1) {
                string += parts[i].charAt(0) + parts[i].substr(1).toLowerCase();
            } else {
                string += parts[i];
            }
        }
    }
    return string;
};

GA.Enum_Base = GA.Class.makeClass('GA.Enum', GA.Enum_Base);

/**
 * @fn static Enum makeEnum(String name, array<String> values, Object methods)
 * @public @memberof GA::Enum
 * Creates a new enum which is a subclass of Enum. New enum class has defined static methods: Enum getValueOf(String
 * name) and array<Enum> getValues().
 * @param name enum full name (with namespaces).
 * @param values array with enum values (use only upper case!).
 * @param methods object which contains enum methods.
 * @return a new enum which is a subclass of Enum.
 * @throws Exception if methods object contains invalid constructor definition.
 * @throws Exception if values array contains invalid data.
 */
/**
 * @fn static Enum makeEnum(String name, array<String> values)
 * @public @memberof GA::Enum
 * Creates a new enum which is a subclass of Enum. New enum class has defined static methods: Enum getValueOf(String
 * name) and array<Enum> getValues().
 * @param name enum full name (with namespaces).
 * @param values array with enum values (use only upper case!).
 * @return a new enum which is a subclass of Enum.
 * @throws Exception if methods object contains invalid constructor definition.
 * @throws Exception if values array contains invalid data.
 */
/**
 * @fn static Enum makeEnum(String name, array<Object<String name, Object params>> valuesWithArgs, Object methods)
 * @public @memberof GA::Enum
 * Creates a new enum which is a subclass of Enum. New enum class has defined static methods: Enum getValueOf(String
 * name) and array<Enum> getValues().
 * @param name enum full name (with namespaces).
 * @param valuesWithArgs array with enum values (use only upper case!) and parameters which will be pass to constructor.
 * @param methods object which contains enum methods.
 * @return a new enum which is a subclass of Enum.
 * @throws Exception if methods object contains invalid constructor definition.
 * @throws Exception if values array contains invalid data.
 */
/**
 * @fn static Enum makeEnum(String name, array<Object<String name, Object params>> valuesWithArgs)
 * @public @memberof GA::Enum
 * Creates a new enum which is a subclass of Enum. New enum class has defined static methods: Enum getValueOf(String
 * name) and array<Enum> getValues().
 * @param name enum full name (with namespaces).
 * @param valuesWithArgs array with enum values (use only upper case!) and parameters which will be pass to constructor.
 * @return a new enum which is a subclass of Enum.
 * @throws Exception if methods object contains invalid constructor definition.
 * @throws Exception if values array contains invalid data.
 */
GA.Enum.makeEnum = function(name, values, methods) {
    if( typeof methods === 'undefined') {
        methods = {};
    }
    if(values.length === 0) {
        throw 'Array with values cannot be empty';
    }

    GA.Enum._addConstructorIfDoesNotExist(methods);
    var enumClass = GA.Class.makeClass(name, GA.Enum_Base, methods);
    var enumValues = GA.Enum._createValues(enumClass, values);
    var sortedNames = GA.Enum._getSortedNames(values);
    GA.Enum._copyValues(enumClass, enumValues);
    enumClass.getValueOf = GA.Enum._createGetValueOfMethod(enumClass, enumValues);
    enumClass.getValues = GA.Enum._createGetValuesMethod(enumClass, sortedNames);
    return enumClass;
};

GA.Enum._addConstructorIfDoesNotExist = function(methods) {
    if( typeof methods.initialize === 'undefined') {
        methods.initialize = function(name) {
            this.callSuper(name);
        };
    }
};

GA.Enum._createValues = function(enumClass, values) {
    if( typeof values[0] === 'string') {
        return GA.Enum._createValuesFromStrings(enumClass, values);
    } else {
        return GA.Enum._createValuesFromObjects(enumClass, values);
    }
};

GA.Enum._createValuesFromStrings = function(enumClass, values) {
    var enumValues = [];
    for(var i = 0; i < values.length; ++i) {
        if( typeof values[i] !== 'string') {
            throw new GA.Exception('Illegal enum value type (should be string)!');
        }
        var value = values[i];
        enumValues[enumValues.length] = new enumClass(value);
    }
    return enumValues;
};

GA.Enum._createValuesFromObjects = function(enumClass, values) {
    var enumValues = [];
    for(var i = 0; i < values.length; ++i) {
        var value;
        var params;
        if( typeof values[i] === 'object' && typeof values[i].name === 'string' && typeof values[i].params === 'object') {
            value = values[i].name;
            params = values[i].params;
        } else {
            throw new GA.Exception('Illegal enum value type (should be object with fields: String name, Object params)!');
        }
        enumValues[enumValues.length] = new enumClass(value, params);
    }
    return enumValues;
};

GA.Enum._getSortedNames = function(values) {
    var sortedNames = [];
    if( typeof values[0] === 'string') {
        for(var i = 0; i < values.length; ++i) {
            sortedNames[i] = values[i];
        }
    } else {
        for(var j = 0; j < values.length; ++j) {
            sortedNames[j] = values[j].name;
        }
    }
    return sortedNames.sort();
};

GA.Enum._copyValues = function(enumClass, enumValues) {
    for(var i = 0; i < enumValues.length; ++i) {
        enumClass[enumValues[i].getName()] = enumValues[i];
    }
};

GA.Enum._createGetValueOfMethod = function(enumClass, enumValues) {
    var values = [];
    for(var i = 0; i < enumValues.length; ++i) {
        values[enumValues[i].getName()] = enumValues[i];
    }
    return function(name) {
        if( typeof values[name] !== 'undefined') {
            return values[name];
        }
        return null;
    };
};

GA.Enum._createGetValuesMethod = function(enumClass, sortedNames) {
    var enumValues = [];
    for(var i = 0; i < sortedNames.length; ++i) {
        enumValues[i] = enumClass[sortedNames[i]];
    }
    return function() {
        return enumValues;
    };
};
