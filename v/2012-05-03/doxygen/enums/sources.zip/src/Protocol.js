/**
 * @file src/Protocol.js
 * Contains GA::Protocol enum.
 */

/**
 * @enum GA::Protocol
 * @extends GA::Enum
 * Represents network protocols.
 */
// XXX delete when doxygen correct https://bugzilla.gnome.org/show_bug.cgi?id=674983
/**
 * @fn static Enum makeEnum(String name, array<String> values, Object methods)
 * @private @memberof GA::Protocol
 */
/**
 * @fn static Enum makeEnum(String name, array<String> values)
 * @private @memberof GA::Protocol
 */
/**
 * @fn static Enum makeEnum(String name, array<Object<String name, Object params>> valuesWithArgs, Object methods)
 * @private @memberof GA::Protocol
 */
/**
 * @fn static Enum makeEnum(String name, array<Object<String name, Object params>> valuesWithArgs)
 * @private @memberof GA::Protocol
 */
GA.Protocol = [];
// XXX edit when docygen correct https://bugzilla.gnome.org/show_bug.cgi?id=674983
/**
 * @typedef GeometryOperand HTTP
 * @memberof GA::Protocol
 * HTTP protocol.
 */
GA.Protocol.push('HTTP');
/**
 * @typedef GeometryOperand HTTPS
 * @memberof GA::Protocol
 * HTTPS protocol.
 */
GA.Protocol.push('HTTPS');
/**
 * @typedef GeometryOperand FTP
 * @memberof GA::Protocol
 * FTP protocol.
 */
GA.Protocol.push('FTP');
/**
 * @typedef GeometryOperand FTPS
 * @memberof GA::Protocol
 * FTPS protocol.
 */
GA.Protocol.push('FTPS');

GA.Protocol = GA.Enum.makeEnum('GA.Protocol', GA.Protocol);

/**
 * @fn static Protocol getValueOf(String name)
 * @public @memberof GA::Protocol
 * Returns the enum constant of the specified enum type with the specified name. The name must match exactly an
 * identifier used to declare an enum constant in this type.
 * @return the enum constant or null.
 */
// GA.Enum.makeEnum creates this method
/**
 * @fn static array<Protocol> getValues()
 * @public @memberof GA::Protocol
 * Returns array with all specified enum values.
 * @return array with all specified enum values.
 */
// GA.Enum.makeEnum creates this method