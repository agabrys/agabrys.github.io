JS.ENV.ClassTest = JS.Test.describe('GA.Class', function() {

    this.it('test_create_instance_of_class_without_constructor_definition', function() {
        var Class = {};
        Class = GA.Class.makeClass('Class', Class);
        try {
            var obj = new Class();
        } catch (exception) {
            this.assert(false, exception.toString());
        }
    });

    this.it('test_create_class_with_invalid_constructor_definition', function() {
        var Class = {};
        Class.initialize = null;
        try {
            GA.Class.makeClass('Class', Class);
            this.assert(false, 'Create class with constructor equals to null');
        } catch (exception1) {
            //ok
        }
        Class = {};
        Class.initialize = {};
        try {
            GA.Class.makeClass('Class', Class);
            this.assert(false, 'Create class with constructor equals to object');
        } catch (exception2) {
            // ok
        }
        Class = {};
        Class.initialize = [];
        try {
            GA.Class.makeClass('Class', Class);
            this.assert(false, 'Create class with constructor equals to array');
        } catch (exception3) {
            // ok
        }
        Class = {};
        Class.initialize = 'string';
        try {
            GA.Class.makeClass('Class', Class);
            this.assert(false, 'Create class with constructor equals to string');
        } catch (exception4) {
            // ok
        }
        Class = {};
        Class.initialize = 2;
        try {
            GA.Class.makeClass('Class', Class);
            this.assert(false, 'Create class with constructor equals to number');
        } catch (exception5) {
            // ok
        }
    });

    this.it('test_inheritance_child_without_constructor_definition', function() {
        var Parent = {};
        Parent.initialize = function() {
            this.callSuper();
            this.value = 'value';
        };
        Parent = GA.Class.makeClass('Parent', Parent);

        var Child = {};
        Child = GA.Class.makeClass('Child', Parent, Child);

        var parent = new Parent();
        this.assertSame('value', parent.value);
        var child = new Child();
        this.assertSame('value', child.value);
    });

    this.it('test_inheritance_parent_without_constructor_definition', function() {
        var Parent = {};
        Parent = GA.Class.makeClass('Parent', Parent);

        var Child = {};
        Child.initialize = function() {
            this.callSuper();
            this.value = 'value';
        };
        Child = GA.Class.makeClass('Child', Parent, Child);

        var parent = new Parent();
        this.assert( typeof parent.value === 'undefined');
        var child = new Child();
        this.assertSame('value', child.value);
    });

    this.it('test_inheritance_with_fixed_value', function() {
        var Parent = {};
        Parent.initialize = function() {
            this.callSuper();
            this.value = 'Parent';
        };
        Parent = GA.Class.makeClass('Parent', Parent);

        var Child = {};
        Child.initialize = function() {
            this.callSuper();
            this.value = 'Child';
        };
        Child = GA.Class.makeClass('Child', Parent, Child);

        var parent = new Parent();
        this.assertSame('Parent', parent.value);
        var child = new Child();
        this.assertSame('Child', child.value);
    });

    this.it('test_depth_inheritance', function() {
        var Parent = {};
        Parent.initialize = function() {
            this.callSuper();
            this.value = 'Parent';
        };
        Parent = GA.Class.makeClass('Parent', Parent);

        var Child = {};
        Child = GA.Class.makeClass('Child', Parent, Child);

        var GrandChild = {};
        GrandChild.initialize = function() {
            this.callSuper();
            this.value = 'GrandChild';
        };
        GrandChild = GA.Class.makeClass('GrandChild', Child, GrandChild);
        var parent = new Parent();
        this.assertSame('Parent', parent.value);
        var child = new Child();
        this.assertSame('Parent', child.value);
        var grandChild = new GrandChild();
        this.assertSame('GrandChild', grandChild.value);
    });

    this.it('test_convert_namespaces', function() {
        var Class = GA.Class.makeClass('Namespace::Subnamespace::Class', {});
        this.assertSame('Namespace.Subnamespace.Class', Class.toString());
    });

    this.it('_isCallParentConstructor_no', function() {
        var func = function() {
            // do nothing
        };
        this.assertSame(false, GA.Class._isCallParentConstructor(GA.Class._getFunctionBodyInString(func)));
    });

    this.it('_isCallParentConstructor_yes', function() {
        var func = function() {
            this.callSuper();
        };
        this.assertSame(true, GA.Class._isCallParentConstructor(GA.Class._getFunctionBodyInString(func)));
    });

    this.it('_isCallParentConstructor_yes_with_params', function() {
        var func = function() {
            this.callSuper(1, 2);
        };
        this.assertSame(true, GA.Class._isCallParentConstructor(GA.Class._getFunctionBodyInString(func)));
    });

    this.it('_isThrowExceptionInFirstInstruction_yes', function() {
        var func = function() {
            throw 'exception';
        };
        this.assertSame(true, GA.Class._isThrowExceptionInFirstInstruction(GA.Class._getFunctionBodyInString(func)));
    });

    this.it('_isThrowExceptionInFirstInstruction_no', function() {
        var func = function() {
            var i = 0;
            throw 'exception';
        };
        this.assertSame(false, GA.Class._isThrowExceptionInFirstInstruction(GA.Class._getFunctionBodyInString(func)));
    });

    this.it('_getFunctionBodyInString', function() {
        var func = function(a, b) {
            return a + b;
        };
        var functionBody = GA.Class._getFunctionBodyInString(func);
        this.assertSame('return a + b;', functionBody);
    });

    this.it('isA', function() {
        var ParentA = GA.Class.makeClass('ParentA', {});
        var ParentB = GA.Class.makeClass('ParentB', {});
        var ChildA = GA.Class.makeClass('ChildA', ParentA, {});
        var ChildB = GA.Class.makeClass('ChildB', ParentB, {});
        var childA = new ChildA();
        this.assertSame(true, childA.isA(ChildA));
        this.assertSame(true, childA.isA(ParentA));
        this.assertSame(false, childA.isA(ChildB));
        this.assertSame(false, childA.isA(ParentB));
        this.assertSame(false, childA.isA({}));
        this.assertSame(false, childA.isA('ala'));
        this.assertSame(false, childA.isA([]));
        this.assertSame(false, childA.isA(1));
    });
});
