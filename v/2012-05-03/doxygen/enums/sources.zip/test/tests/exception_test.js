JS.ENV.ExceptionTest = JS.Test.describe('GA.Exception', function() {

    this.it('getStackTraceString', function() {
        var exception1 = new GA.Exception('exception1');
        var stackTraceString = 'GA.Exception: exception1\n';
        var exception2 = new GA.Exception('exception2', exception1);
        stackTraceString = 'GA.Exception: exception2\n' + stackTraceString;
        var exception3 = new GA.Exception(exception2);
        stackTraceString = 'GA.Exception: exception2\n' + stackTraceString;
        this.assertSame(stackTraceString, exception3.getStackTraceString());
    });
});
