JS.ENV.CSW = JS.ENV.GA.CSW;

JS.ENV.ProtocolTest = JS.Test.describe('GA.Protocol', function() {

    this.it('getValueOf', function() {
        this.assertSame(true, GA.Protocol.HTTP.equals(GA.Protocol.getValueOf('HTTP')));
        this.assertSame(true, GA.Protocol.HTTPS.equals(GA.Protocol.getValueOf('HTTPS')));
        this.assertSame(true, GA.Protocol.FTP.equals(GA.Protocol.getValueOf('FTP')));
        this.assertSame(true, GA.Protocol.FTPS.equals(GA.Protocol.getValueOf('FTPS')));
    });

    this.it('getValues', function() {
        var values = GA.Protocol.getValues();
        this.assertSame(4, values.length);
        var found = {
            HTTP: false,
            HTTPS: false,
            FTP: false,
            FTPS: false
        };
        for(var i = 0; i < values.length; ++i) {
            found[values[i].getName()] = true;
        }
        this.assertSame(true, found.HTTP);
        this.assertSame(true, found.HTTPS);
        this.assertSame(true, found.FTP);
        this.assertSame(true, found.FTPS);
    });
});
