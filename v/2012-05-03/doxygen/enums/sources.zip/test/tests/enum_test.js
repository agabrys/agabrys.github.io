JS.ENV.EnumTest = JS.Test.describe('GA.Enum', function() {

    this.it('makeEnum_strings', function() {
        var values = ['ONE', 'TWO', 'THREE'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame(true, typeof Enum.ONE === 'object');
        this.assertSame(true, typeof Enum.TWO === 'object');
        this.assertSame(true, typeof Enum.THREE === 'object');
        this.assertSame('ONE', Enum.ONE.getName());
        this.assertSame('TWO', Enum.TWO.getName());
        this.assertSame('THREE', Enum.THREE.getName());
    });

    this.it('makeEnum_objects', function() {
        var values = [{
            name: 'ONE',
            params: {
                value: 1
            }
        }, {
            name: 'TWO',
            params: {
                value: 2
            }
        }, {
            name: 'THREE',
            params: {
                value: 3
            }
        }];
        var Enum = {};
        Enum.initialize = function(name, params) {
            this.callSuper(name);
            this._value = params.value;
        };
        Enum.getValue = function() {
            return this._value;
        };
        Enum = GA.Enum.makeEnum('Enum', values, Enum);
        this.assertSame(true, typeof Enum.ONE === 'object');
        this.assertSame(true, typeof Enum.TWO === 'object');
        this.assertSame(true, typeof Enum.THREE === 'object');
        this.assertSame('ONE', Enum.ONE.getName());
        this.assertSame('TWO', Enum.TWO.getName());
        this.assertSame('THREE', Enum.THREE.getName());
        this.assertSame(1, Enum.ONE.getValue());
        this.assertSame(2, Enum.TWO.getValue());
        this.assertSame(3, Enum.THREE.getValue());
    });

    this.it('equals', function() {
        var values = ['ONE', 'TWO'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame(false, Enum.ONE.equals(Enum.TWO));
        this.assertSame(false, Enum.TWO.equals(Enum.ONE));
        this.assertSame(false, Enum.ONE.equals(null));
        this.assertSame(false, Enum.ONE.equals('string'));
        this.assertSame(true, Enum.ONE.equals(Enum.ONE));
        var Enum2 = GA.Enum.makeEnum('Enum2', values, {});
        this.assertSame(false, Enum.ONE.equals(Enum2.ONE));
        this.assertSame(false, Enum.TWO.equals(Enum2.TWO));
    });

    this.it('isA', function() {
        var values = ['ONE', 'TWO', 'THREE'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame(true, Enum.ONE.isA(Enum));
        this.assertSame(true, Enum.TWO.isA(Enum));
        this.assertSame(true, Enum.THREE.isA(Enum));
        this.assertSame(true, Enum.ONE.isA(GA.Enum));
        this.assertSame(true, Enum.TWO.isA(GA.Enum));
        this.assertSame(true, Enum.THREE.isA(GA.Enum));
        var Enum2 = GA.Enum.makeEnum('Enum2', ['TEST']);
        this.assertSame(false, Enum.ONE.isA(Enum2));
        this.assertSame(false, Enum.TWO.isA(Enum2));
        this.assertSame(false, Enum.THREE.isA(Enum2));
    });

    this.it('getValues', function() {
        var values = ['ONE', 'TWO', 'THREE'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame(3, Enum.getValues().length);
        this.assertSame(true, Enum.ONE.equals(Enum.getValues()[0]));
        this.assertSame(true, Enum.THREE.equals(Enum.getValues()[1]));
        this.assertSame(true, Enum.TWO.equals(Enum.getValues()[2]));
    });

    this.it('getValueOf', function() {
        var values = ['ONE', 'TWO', 'THREE'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame(true, Enum.ONE.equals(Enum.getValueOf(values[0])));
        this.assertSame(true, Enum.TWO.equals(Enum.getValueOf(values[1])));
        this.assertSame(true, Enum.THREE.equals(Enum.getValueOf(values[2])));
    });

    this.it('toString', function() {
        var values = ['ONE_VAL', 'TWO_A_VAL', 'THREE__A_VAL'];
        var Enum = GA.Enum.makeEnum('Enum', values);
        this.assertSame('OneVal', Enum.ONE_VAL.toString());
        this.assertSame('TwoAVal', Enum.TWO_A_VAL.toString());
        this.assertSame('ThreeAVal', Enum.THREE__A_VAL.toString());
    });
});
