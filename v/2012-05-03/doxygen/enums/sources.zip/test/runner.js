var sourceClassPath = '/src';
var testClassPath = '/test/tests';

JS.Packages(function() {
    var ROOT = ( typeof JS.ENV.ROOT === 'undefined' ? '.' : JS.ENV.ROOT);

    this.autoload(/(.*)Test$/, {
        from: ROOT + testClassPath,
        require: 'GA.$1'
    });

    this.file(ROOT + sourceClassPath + '/init.js').provides('GA');
    this.file(ROOT + sourceClassPath + '/Class.js').provides('GA.Class').requires('GA', 'JS.Class');
    this.file(ROOT + sourceClassPath + '/Enum.js').provides('GA.Enum').requires('GA.Class', 'GA.Exception');
    this.file(ROOT + sourceClassPath + '/Exception.js').provides('GA.Exception').requires('GA.Class');
    this.file(ROOT + sourceClassPath + '/Protocol.js').provides('GA.Protocol').requires('GA.Enum');

});

JS.require('JS.Test', function() {
    var tests = [];
    tests.push('ClassTest');
    tests.push('EnumTest');
    tests.push('ExceptionTest');
    tests.push('ProtocolTest');

    tests.push(JS.Test.method('autorun'));
    JS.require.apply(JS, tests);
});
