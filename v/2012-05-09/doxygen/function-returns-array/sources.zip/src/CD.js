/**
 * @file src/CD.js
 * Represents CD disk.
 */

/**
 * @class CD
 * Represents CD disk.
 */

/**
 * @fn CD CD(String[] songs)
 * @public @memberof CD
 * Constructor.
 * @param songs songs.
 */
var CD = function(songs) {
    this.songs = songs;
};
/**
 * @fn int getSongsCount()
 * @public @memberof CD
 * Returns songs count.
 * @return songs count.
 */
CD.prototype.getSongsCount = function() {
    return this.songs.length;
};
/**
 * @fn String getSong(int index)
 * @public @memberof CD
 * Returns song associated with index or null if index is equals or bigger than {@link #getSongsCount}.
 * @return song associated with index or null if index is equals or bigger than {@link #getSongsCount}.
 */
CD.prototype.getSong = function(index) {
    if(index >= this.songs.length) {
        return null;
    }
    return this.songs[index];
};
/**
 * @fn String[] getSongs()
 * @public @memberof CD
 * Returns all songs.
 * @return all songs.
 */
CD.prototype.getSongs = function() {
    return this.songs.slice(0);
};
/**
 * @fn String toString()
 * @public @memberof CD
 * Returns text containing songs list ({@link #getSongs()}). Songs name are separated by "," char.
 * @return text containing songs list.
 */
CD.prototype.toString = function() {
    this.songs.toString();
};
